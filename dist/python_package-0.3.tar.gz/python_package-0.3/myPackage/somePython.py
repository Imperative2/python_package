import numpy

def calc(temp):


    return temp