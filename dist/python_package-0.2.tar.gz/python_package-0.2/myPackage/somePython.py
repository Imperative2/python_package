import numpy

def calc(temp):
    '''
    takes a temperature `temp` in fahrenheit and returns it in Kelvin
    '''


    return temp